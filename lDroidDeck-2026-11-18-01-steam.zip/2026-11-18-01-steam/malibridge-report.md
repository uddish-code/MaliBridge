Mode: safe (Setup) - emulations and errata fixes stay on wherever the startup probe has not verified the native path on this GPU and driver; compile watchdog 10 s (safe mode).

# MaliBridge session report

Session started 2026-11-18 12:26:40, report written 2026-11-18 15:20:34 (10374 s in); rewritten every 5 s. Machine-readable: `malibridge-report.json`.

> **Warning, test switch on: overrides from /data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/env in effect: VKBRIDGE_HUD_FPS=12 VKBRIDGE_PACER=1**

## Summary: 27 issues

1. test switch on: overrides from /data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/env in effect: VKBRIDGE_HUD_FPS=12 VKBRIDGE_PACER=1
2. probe dmabuf_linear_image: fail (1D 4096x1 R32F: query -11, create -1000158000; 2D 8x8 RGBA8: query -11, create -1000158000 - handled at run time: such images are made without the handle type (server_emu_layer.c))
3. probe linear_layout: fail (1x1: rowPitch 0 size 64; 1x16: rowPitch 64 size 1024; 16x1: rowPitch 0 size 64 - patched at run time (the server reports the row's size))
4. probe spec_select: fail -> SPIR-V spec-constant fix on (selected 0 0 0 0 (want 11 22 33 44; zeros: folded at the defaults) - the SPIR-V fix (server_spvfix.c) is on for Arm's driver)
5. probe bitwise_vec: fail -> the bug's pattern (MK-03): vector bitwise ops miscompiled (case 0 lanes 0x11 0x2 (want 0x11 0x3) - integer vector bitwise ops miscompiled)
6. probe view3d_layers: crash (the driver faulted (signal 11); the probe device is abandoned)
7. probe pv_mutable_linear: fail (RGBA8: query 0, image export fd (0); BGRA8: query 0, image export fd (0) - the query says yes and the image fails: not the refusal pattern, pv_mutable_linear stays off)
8. warning gamescope: compute layout: immutable YCbCr samplers replaced (this GPU cannot build such pipelines); NV12 surfaces lose YCbCr conversion (x1, first at 1.6 s)
9. gamescope: CPU clocks capped to 35% of their maximum while it ran (thermal)
10. gamescope: Android thermal status reached 3
11. Xwayland: CPU clocks capped to 35% of their maximum while it ran (thermal)
12. Xwayland: Android thermal status reached 3
13. Xwayland: CPU clocks capped to 35% of their maximum while it ran (thermal)
14. Xwayland: Android thermal status reached 3
15. steam: CPU clocks capped to 35% of their maximum while it ran (thermal)
16. steam: CPU held at a fixed clock while it ran: p0 1600 MHz 64% of the time (the phone's power mode or a per-app limit may be holding it)
17. steam: Android thermal status reached 3
18. steamwebhelper: CPU clocks capped to 35% of their maximum while it ran (thermal)
19. steamwebhelper: Android thermal status reached 3
20. steamwebhelper: CPU clocks capped to 35% of their maximum while it ran (thermal)
21. steamwebhelper: Android thermal status reached 3
22. explorer.exe (steam3960647599): CPU clocks capped to 35% of their maximum while it ran (thermal)
23. explorer.exe (steam3960647599): Android thermal status reached 3
24. SkyrimSE.exe (steam3960647599): 2 GPU wait(s) longer than 2 s (longest 8.6 s)
25. SkyrimSE.exe (steam3960647599): CPU clocks capped to 35% of their maximum while it ran (thermal)
26. SkyrimSE.exe (steam3960647599): CPU held at a fixed clock while it ran: p0 1600 MHz 64% of the time (the phone's power mode or a per-app limit may be holding it)
27. SkyrimSE.exe (steam3960647599): Android thermal status reached 3

## Notes (not problems)

1. steam: presents stopped 10366 s before it exited; another program was in front (normal)
2. explorer.exe (steam3960647599): a device for 10356 s and no frame presented; another program was in front (normal)

## Device

| | |
|---|---|
| model | samsung SM-X820 (aarch64) |
| SoC | MT6989 |
| Android | 16 (SDK 36), build BP4A.251205.006.X820XXU7DZE3 |
| kernel | Linux 6.1.145-android14-11-abX820XXU7DZE3 |
| memory | 11525 MB total, 1568 MB available at the lowest |
| storage | 31809 MB free where the caches live |
| clocks | CPU clusters capped to 35% at the lowest; GPU clock not readable; Android thermal status max 3 (vkbridge-clocks.log) |
| server | pid 9644, its own process, RSS peak 3089 MB |
| GPU 0 | Mali-G720-Immortalis MC12, Vulkan 1.3.247 to the server; memory sharing dmaheap; missing 0x461deef, emulating 0x463ffff |

## Bridge

Build `v0.5.5-441-g5b8c16c`, protocol `e88f0e43c2b566b9`. Cache directory `/data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines`.

Overrides from `<cache dir>/env`: `VKBRIDGE_HUD_FPS=12 VKBRIDGE_PACER=1`

Server environment: (no VKBRIDGE_/VK_ variables)

## Startup probe

Profile `/data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/probe-13b5-c8700000-0b001000-1eaa44767a701f8f.json` - Mali-G720-Immortalis MC12, Mali-G720-Immortalis MC12 v1.r44p1-01eac0.97cfdb5d49b593ea0a6dc1bdbc33dec8; from the cache, 1 ms at start (background part pending).

Emulation mask: 0x463ffff before the probe; after it 0x463ffff in safe mode, 0x463ffff in performance mode (safe mode in force: a probe that has not verified the native path keeps its emulation).

| probe | result | ms | decision (safe mode) | detail |
|---|---|---:|---|---|
| identity | pass | 1.3 |  | Mali-G720-Immortalis MC12, Vulkan 1.3.247, driver 0x0b001000 (Mali-G720-Immortalis MC12: v1.r44p1-01eac0.97cfdb5d49b593ea0a6dc1bdbc33dec8), 119 device extensions |
| memory_types | pass | 0.5 |  | 0:0x7=ok,mapped 1:0xb=ok,mapped 2:0x11=ok 3:0x21=protected; images: types 0x3, ordinary device-local 0 |
| dma_heaps | pass | 0.2 |  | mtk_prot_region-aligned=ok mtk_prot_region=ok mtk_sapu_data_shm_region-aligned=ok mtk_sapu_data_shm_region=ok mtk_sapu_engine_shm_region-aligned=ok mtk_sapu_engine_shm_region=ok mtk_svp_region-aligned=ok mtk_svp_region=ok mtk_wfd_region-aligned=ok mtk_wfd_region=ok mtk_tui_region-aligned=Permission denied mtk_tui_region=Permission denied mtk_prot_page-uncached=ok mtk_sapu_page-uncached=Permission denied mtk_svp_page-uncached=ok mtk_wfd_page-uncached=ok mtk_camera-uncached=Permission denied mtk_mm=ok system=ok mtk_camera=Permission denied mtk_mm-uncached=ok system-uncached=ok mtk_slc=Permission denied; the bridge's dma-heap: availab |
| dmabuf_export | skip | 0.0 |  | query (optimal RGBA8): -11, features 0x0; not claimed exportable (emulated, pages from the dma-heap) |
| dmabuf_linear_image | **fail** | 0.0 |  | 1D 4096x1 R32F: query -11, create -1000158000; 2D 8x8 RGBA8: query -11, create -1000158000 - handled at run time: such images are made without the handle type (server_emu_layer.c) |
| ahb_share | skip | 0.0 |  | not needed: the driver takes dma-bufs |
| linear_layout | **fail** | 0.4 |  | 1x1: rowPitch 0 size 64; 1x16: rowPitch 64 size 1024; 16x1: rowPitch 0 size 64 - patched at run time (the server reports the row's size) |
| compressed_formats | pass | 0.0 |  | BC1:--- BC3:--- BC4:--- BC5:--- BC6H:--- BC7:--- ETC2:sft EAC-RG11s:sft ASTC4x4:sft ASTC4x4-HDR:sft (s sampled, f linear filter, t transfer dst) |
| bc_native | skip | 0.0 |  | BC emulated |
| compression | pass | 0.3 |  | plain: compression 0x0; storage: compression 0x4 (0x0 default/compressed, 0x4 disabled) |
| descriptor_pool | pass | 0.1 |  | pool for 16 sets gave 16, then -1000069000 |
| bindless_limits | pass | 0.0 |  | UAB per stage: sampled 500000 storage img 500000 storage buf 500000; 500000: support 1, create 0; 1000000: support 0, create 0 |
| null_descriptor | skip | 0.0 |  | robustness2 emulated (null stand-ins) |
| push_descriptor | skip | 0.0 |  | push descriptors emulated |
| multi_draw_indirect | pass | 14.6 |  | 2 draws in one indirect call: 0 0 255 0 0 255 0 0 (want columns 2 and 5) |
| divisor | skip | 0.0 |  | divisor emulated |
| depth_clip | skip | 0.0 |  | depth clip emulated |
| clip_distance | skip | 0.0 |  | clip distance emulated |
| spec_select | **fail** | 5.7 | SPIR-V spec-constant fix on | selected 0 0 0 0 (want 11 22 33 44; zeros: folded at the defaults) - the SPIR-V fix (server_spvfix.c) is on for Arm's driver |
| waits | pass | 3.3 |  | unsignalled fence: wait 0 -> 2, 1 ms -> 2; timeline at 0, wait for 1: 0 -> 2, 2 ms -> 2 after 2.1 ms; signalled by a submission (0): wait -> 0, value 1 |
| layer_vs | pass | 5.1 |  | 8 points into layer 1: layer 0 has 0, layer 1 has 8 (compiled in 3.4 ms) |
| layer_gs | pass | 23.5 |  | 8 points into layer 1: layer 0 has 0, layer 1 has 8 (compiled in 19.8 ms) |
| pipeline_cache | pass | 3.7 |  | cold 3.4 ms, from 1713 bytes of cache data 0.0 ms (cache from data: 0) |
| viewport_flip | pass | 6.7 |  | viewport (0,4,4,-4) rows lit 0011 (want 0011), (4,0,4,4) 1100 (want 1100); facing front / back (want different); no multiViewport with the VS's ViewportIndex: two viewports not tried |
| bitwise_vec | **fail** | 8.2 | the bug's pattern (MK-03): vector bitwise ops miscompiled | case 0 lanes 0x11 0x2 (want 0x11 0x3) - integer vector bitwise ops miscompiled |
| dyn_state | pass | 10.8 |  | after a bind: depth write off kept (rgb 0 0 255), cull FRONT_AND_BACK kept, stencil write mask 0 kept (stencil 0); no EDS3 sample mask |
| vb_strides | pass | 4.9 |  | one call from binding 0: right; one call from binding 1: right; single-binding calls: right |
| view3d_layers | **crash** | 0.3 |  | the driver faulted (signal 11); the probe device is abandoned |
| pv_mutable_linear | **fail** | 0.1 |  | RGBA8: query 0, image export fd (0); BGRA8: query 0, image export fd (0) - the query says yes and the image fails: not the refusal pattern, pv_mutable_linear stays off |
| pv_bgra_store | skip | 0.0 |  | not a PowerVR driver: not run |
| pv_names | skip | 0.0 |  | not a PowerVR driver: not run |
| fp16_math | pass | 16.3 |  | fma, range, conversions, relaxed precision and a 16-bit accumulation right |
| wait_eintr | pass | 1000.4 |  | fence, 500 ms wait, 3 signal(s) into it: 2 after 500 ms; timeline semaphore, 500 ms wait, 3 signal(s) into it: 2 after 500 ms |
| rendering_churn | pass | 248.5 |  | 256 views made, rendered to, read back and destroyed: 0 wrong |
| compile_lut_standin | pass | 16.0 |  | the compile watchdog's LUT stand-in: built in 16 ms |
| compile_aces | pass | 167.6 |  | UE4-LUT-shaped fragment shader (56348 bytes of SPIR-V): built in 167 ms |
| bc_transcoders | pass | 1204.9 |  | BC1->ETC2 0 ms, BC2->ASTC 0 ms, BC3->ASTC 0 ms, BC4->EAC 0 ms, BC5->EAC 0 ms, BC6H->ASTC-HDR 0 ms, BC7->ASTC 1187 ms |
| bc_variants | pass | 18777.9 |  | 26 same as the old variants |

Driver errata, GPU 0 (decided at each vkCreateDevice; mode now: safe):

| erratum | item | probe | probe result | safe mode | performance mode |
|---|---|---|---|---|---|
| wait_retry | MK-01 | wait_eintr (records) | pass | **ON** (always; safe mode; probe wait_eintr passed, recorded only) - in force | **ON** (always; performance mode; probe wait_eintr passed, recorded only) | 
| viewport_flip | MK-02 | viewport_flip | pass | off (not needed here) - in force | off (not needed here) | 
| bitwise_scalar | MK-03 | bitwise_vec | **fail (or)** | **ON** (probe bitwise_vec failed; r44p1 in r18p0-r53; safe mode) - in force | **ON** (probe bitwise_vec failed; performance mode) | 
| dyn_reemit | MK-04 | dyn_state | pass | off (not needed here) - in force | off (not needed here) | 
| vb_split | MK-05 | vb_strides (records) | pass | **ON** (always; safe mode; probe vb_strides passed, recorded only) - in force | **ON** (always; performance mode; probe vb_strides passed, recorded only) | 
| view_quarantine | MK-06 | rendering_churn (records) | pass | **ON** (always; safe mode; probe rendering_churn passed, recorded only) - in force | off (not needed here) | 
| view_counts | MK-07 | view3d_layers (records) | **crash** | **ON** (always; safe mode) - in force | **ON** (always; performance mode) | 
| clamp_zero | MK-32 | none (by version) | - | **ON** (r44p1 in r38p1-r49p0; safe mode) - in force | **ON** (r44p1 in r38p1-r49p0; performance mode) | 
| cull_nontri | MK-16 | none (by version) | - | **ON** (always; safe mode) - in force | **ON** (r44p1 in r0p0-r51 (ANGLE: below r52; Arm: r41p0-r49p2, r50p0-r51p0); performance mode) | 
| dedicated_import | MK-39 | none (by version) | - | **ON** (r44p1 in r0p0-r54p0 (fixed between r32p1 and r54p1); safe mode) - in force | **ON** (r44p1 in r0p0-r54p0 (fixed between r32p1 and r54p1); performance mode) | 
| fp16_hide | MK-20 | fp16_math | pass | off (not needed here) - in force | off (not needed here) | 
| stencil_layout | MK-11 | none (by version) | - | **ON** (r44p1 in r41p0-r54p0 (Arm 4021056, fixed in r54p1); safe mode) - in force | **ON** (r44p1 in r41p0-r54p0 (Arm 4021056, fixed in r54p1); performance mode) | 
| vb_bake | MK-05 | vb_strides | pass | off (not needed here) - in force | off (not needed here) | 
| gs_hide | #11 | none (by version) | - | off (not needed here) - in force | off (not needed here) | 
| split_varying | MK-47 | none (by version) | - | **ON** (r44p1 in r0p0-on (every Arm driver (a player log r38p1, a player log r49p1)); safe mode) - in force | **ON** (r44p1 in r0p0-on (every Arm driver (a player log r38p1, a player log r49p1)); performance mode) | 
| import_serial | MK-48 | none (by version) | - | off (not needed here) - in force | off (not needed here) | 
| pv_mutable_linear | PV-02 | pv_mutable_linear | **fail (rgba8, bgra8)** | off (not needed here) - in force | off (not needed here) | 
| pv_bgra_store | PV-07 | pv_bgra_store | skip | off (not needed here) - in force | off (not needed here) | 
| pv_names | PV-01 | pv_names | skip | off (not needed here) - in force | off (not needed here) | 
| pv_view3d_base | PV-04 | view3d_layers | **crash** | off (not needed here) - in force | off (not needed here) | 
| pv_fbloop_split | PV-06 | view3d_layers | **crash** | off (not needed here) - in force | off (not needed here) | 
| pv_zink_name | PV-08 | zink_profile | not run (not a PowerVR driver, or it could not run) | off (not needed here) - in force | off (not needed here) | 
| fragdepth_nodepth | MK-49 | none (by version) | - | off (not needed here) - in force | off (not needed here) | 

## Processes

### droiddeck-vkbri - pid 9838

- application `vkbridge-smoke`, engine vkbridge 0.0.1, Vulkan 1.2 requested
- connected at 0.9 s, first device +0.0 s, exited at 1.0 s (ran 0.1 s); 1 device(s)
- preset: none
- frames: none reported by the client
- pipelines: 5 built in 0.0 s of compile time, longest 1 ms, 0 failed; by time: <10 ms 5, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_push_descriptor VK_EXT_robustness2
- while it ran: GPU memory peak 0 MB; system memory available >= 4390 MB; fastest CPU cluster 2850-2850 MHz, capped to 100%; thermal status max 0

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 1.0 s | capability check: device 2's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 1.0 s | errata: bitwise_scalar ON (probe bitwise_vec failed; r44p1 in r18p0-r53; safe mode) - MK-03 |
| info | 1 | 1.0 s | device 2: null descriptors in push descriptor writes replaced by dummies |
| info | 1 | 1.0 s | device 2: first null descriptors replaced by dummies |
| info | 1 | 1.0 s | device 2: 2 null descriptors replaced, 0 images by stand-ins of their binding's shape; 0 bindings where pipelines disagree on the shape |
| info | 1 | 1.0 s | errata: dedicated_import: 13 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### gamescope - pid 9982

- application `gamescope`, engine hopefully not just some code 1.0.0, Vulkan 1.3 requested
- connected at 1.5 s, first device +0.0 s, exited at 10374.1 s (ran 10372.5 s); 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 37 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 144 built in 0.0 s of compile time, longest 1 ms, 0 failed; by time: <10 ms 144, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_EXT_robustness2
- while it ran: GPU memory peak 40 MB; system memory available >= 1568 MB; fastest CPU cluster 1800-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 64%; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 1.5 s | capability check: device 4's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| warning | 1 | 1.6 s | compute layout: immutable YCbCr samplers replaced (this GPU cannot build such pipelines); NV12 surfaces lose YCbCr conversion |
| info | 1 | 10373.9 s | errata: dedicated_import: 39 import(s), 0 with the dedicated struct taken off, 37 kept (resource made for the handle type); imitated: 0 failed |

### Xwayland - pid 10014

- application `Xwayland`, engine mesa zink 0.0.0, Vulkan 1.4 requested
- connected at 1.9 s, first device +0.0 s, exited at 10374.4 s (ran 10372.5 s); 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 9 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 2 built in 0.0 s of compile time, longest 1 ms, 0 failed; by time: <10 ms 2, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 29 MB; system memory available >= 1568 MB; fastest CPU cluster 1800-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 64%; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 1.9 s | capability check: device 8's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 18.8 s | device 8: first null descriptors replaced by dummies |
| info | 1 | 10374.3 s | vertex input: 2 pipeline(s) kept (at most 10 KB of create infos and shaders at once), 2 variant(s) made (at most 1 for one pipeline), 0 failed, 8 variant bind(s), 0 draw(s) dropped; vkCmdSetVertexInputEXT: 0 passed to the driver, 8 held, 0 sent again; 0 pipeline(s) not kept; 0 extended dynamic state call(s) |
| info | 1 | 10374.3 s | device 8: 30 null descriptors replaced, 0 images by stand-ins of their binding's shape; 0 bindings where pipelines disagree on the shape |
| info | 1 | 10374.3 s | errata: dedicated_import: 26 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### Xwayland - pid 10005

- application `Xwayland`, engine mesa zink 0.0.0, Vulkan 1.4 requested
- connected at 1.9 s, first device +0.0 s, exited at 10374.4 s (ran 10372.5 s); 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 137 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 3 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 3, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 66 MB; system memory available >= 1568 MB; fastest CPU cluster 1800-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 64%; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 1.9 s | capability check: device 7's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 6.0 s | device 7: first null descriptors replaced by dummies |
| info | 1 | 10374.3 s | vertex input: 3 pipeline(s) kept (at most 17 KB of create infos and shaders at once), 3 variant(s) made (at most 1 for one pipeline), 0 failed, 939 variant bind(s), 0 draw(s) dropped; vkCmdSetVertexInputEXT: 0 passed to the driver, 939 held, 0 sent again; 0 pipeline(s) not kept; 0 extended dynamic state call(s) |
| info | 1 | 10374.3 s | device 7: 3780 null descriptors replaced, 0 images by stand-ins of their binding's shape; 0 bindings where pipelines disagree on the shape |
| info | 1 | 10374.3 s | errata: dedicated_import: 144 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### steam - pid 10357

- application `steam`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 4.2 s, first device +0.0 s, first frame +0.2 s, exited at 6.2 s (ran 2.0 s); 1 device(s)
- preset: none
- frames: `pid=10357 comm=steam presents=118 t_first=1106654.445 t_last=1106655.449 fps_avg=116.5 fps_p50=111.1 ft_p50=9 ft_p90=14 ft_p99=17 ft_max=17 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:1 swapchains=1 external=3`
- pipelines: 4 built in 0.0 s of compile time, longest 4 ms, 0 failed; by time: <10 ms 4, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 39 MB; system memory available >= 4040 MB; fastest CPU cluster 1800-1800 MHz, capped to 100%; thermal status max 0

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 4.2 s | capability check: device 10's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 4.4 s | device 10: first null descriptors replaced by dummies |
| info | 1 | 6.0 s | vertex input: 4 pipeline(s) kept (at most 33 KB of create infos and shaders at once), 4 variant(s) made (at most 1 for one pipeline), 0 failed, 570 variant bind(s), 0 draw(s) dropped; vkCmdSetVertexInputEXT: 0 passed to the driver, 570 held, 0 sent again; 0 pipeline(s) not kept; 0 extended dynamic state call(s) |
| info | 1 | 6.1 s | device 10: 2280 null descriptors replaced, 0 images by stand-ins of their binding's shape; 0 bindings where pipelines disagree on the shape |
| info | 1 | 6.1 s | errata: dedicated_import: 8 import(s), 0 with the dedicated struct taken off, 3 kept (resource made for the handle type); imitated: 0 failed |

### steam - pid 10354

- application `steam`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 6.5 s, first device +0.0 s, first frame +1.3 s, exited at 10374.0 s (ran 10367.6 s); 3 device(s)
- preset: none
- frames: `pid=10354 comm=steam presents=1 t_first=1106657.884 t_last=1106657.884 fps_avg=0.0 fps_p50=0.0 ft_p50=0 ft_p90=0 ft_p99=0 ft_max=0 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:0 swapchains=5 external=12`
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 12 MB; system memory available >= 1568 MB; fastest CPU cluster 1800-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 64%; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 3 | 6.5 s | capability check: device 12's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 3 | 6.6 s | errata: dedicated_import: 5 import(s), 0 with the dedicated struct taken off, 3 kept (resource made for the handle type); imitated: 0 failed |

### steamsysinfo - pid 10452

- application `Steam Gpu Query`, engine Steam Gpu Query Engine 1.0.0, Vulkan 1.2 requested
- connected at 6.6 s, exited at 6.7 s (ran 0.1 s); 0 device(s)
- preset: none

### steamwebhelper - pid 10470

- application `steamwebhelper`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 7.3 s, first device +0.0 s, exited at 10374.2 s (ran 10366.9 s); 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 14 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 2 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 2, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 30 MB; system memory available >= 1568 MB; fastest CPU cluster 1800-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 64%; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 7.4 s | capability check: device 19's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 9.7 s | device 19: first null descriptors replaced by dummies |
| info | 1 | 10374.0 s | vertex input: 2 pipeline(s) kept (at most 9 KB of create infos and shaders at once), 2 variant(s) made (at most 1 for one pipeline), 0 failed, 920 variant bind(s), 0 draw(s) dropped; vkCmdSetVertexInputEXT: 0 passed to the driver, 924 held, 0 sent again; 0 pipeline(s) not kept; 0 extended dynamic state call(s) |
| info | 1 | 10374.1 s | device 19: 3696 null descriptors replaced, 0 images by stand-ins of their binding's shape; 0 bindings where pipelines disagree on the shape |
| info | 1 | 10374.1 s | errata: dedicated_import: 18 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### steamwebhelper - pid 10559

- application `steamwebhelper`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 7.6 s, first device +0.2 s, exited at 10374.3 s (ran 10366.8 s); 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 50 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 47 built in 0.0 s of compile time, longest 1 ms, 0 failed; by time: <10 ms 47, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 266 MB; system memory available >= 1568 MB; fastest CPU cluster 1800-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 64%; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 7.8 s | capability check: device 24's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 7.9 s | opaque fd emulation: the driver refused a dma-buf resource; made without (its export will fail) |
| info | 1 | 8.9 s | device 24: first null descriptors replaced by dummies |
| info | 1 | 10374.1 s | vertex input: 47 pipeline(s) kept (at most 290 KB of create infos and shaders at once), 47 variant(s) made (at most 1 for one pipeline), 0 failed, 8197 variant bind(s), 0 draw(s) dropped; vkCmdSetVertexInputEXT: 0 passed to the driver, 4504 held, 0 sent again; 0 pipeline(s) not kept; 0 extended dynamic state call(s) |
| info | 1 | 10374.1 s | device 24: 29683 null descriptors replaced, 0 images by stand-ins of their binding's shape; 0 bindings where pipelines disagree on the shape |
| info | 1 | 10374.2 s | errata: dedicated_import: 72 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### gldriverquery - pid 10541

- application `gldriverquery`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 7.6 s, first device +0.0 s, first frame +0.2 s, exited at 7.8 s (ran 0.2 s); 1 device(s)
- preset: none
- frames: `pid=10541 comm=gldriverquery presents=1 t_first=1106657.858 t_last=1106657.858 fps_avg=0.0 fps_p50=0.0 ft_p50=0 ft_p90=0 ft_p99=0 ft_max=0 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:0 swapchains=2 external=0`
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 7.7 s | capability check: device 22's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 7.8 s | errata: dedicated_import: 4 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### gldriverquery - pid 10630

- application `gldriverquery`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 8.1 s, first device +0.0 s, first frame +0.1 s, exited at 8.2 s (ran 0.2 s); 1 device(s)
- preset: none
- frames: `pid=10630 comm=gldriverquery presents=1 t_first=1106658.260 t_last=1106658.260 fps_avg=0.0 fps_p50=0.0 ft_p50=0 ft_p90=0 ft_p99=0 ft_max=0 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:0 swapchains=2 external=0`
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 8.1 s | capability check: device 26's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 8.2 s | errata: dedicated_import: 4 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### vulkandriverque - pid 10685

- application `hellovr_vulkan`, engine -, Vulkan 1.0 requested
- connected at 8.3 s, first device +0.0 s, exited at 8.3 s (ran 0.1 s); 1 device(s)
- preset: none
- frames: none reported by the client
- pipelines: 1 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 1, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 8.3 s | capability check: device 28's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |

### vulkandriverque - pid 10694

- application `hellovr_vulkan`, engine -, Vulkan 1.0 requested
- connected at 8.4 s, first device +0.0 s, exited at 8.4 s (ran 0.1 s); 1 device(s)
- preset: none
- frames: none reported by the client
- pipelines: 1 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 1, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 8.4 s | capability check: device 30's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |

### explorer.exe (steam3960647599) - pid 11095

- application `explorer.exe`, engine mesa zink 0.0.0, Vulkan 1.4 requested
- connected at 18.6 s, first device +0.1 s, exited at 10374.5 s (ran 10355.8 s); 1 device(s)
- preset: none
- frames: `pid=11095 comm=explorer.exe presents=0 t_first=0.000 t_last=0.000 fps_avg=0.0 fps_p50=0.0 ft_p50=0 ft_p90=0 ft_p99=0 ft_max=0 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:0 swapchains=1 external=1`
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 4 MB; system memory available >= 1568 MB; fastest CPU cluster 1800-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 64%; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 18.7 s | capability check: device 33's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 10374.4 s | errata: dedicated_import: 5 import(s), 0 with the dedicated struct taken off, 3 kept (resource made for the handle type); imitated: 0 failed |

### SkyrimSE.exe (steam3960647599) - pid 11145 (running)

- application `SkyrimSE.exe`, engine mesa zink 0.0.0, Vulkan 1.4 requested
- connected at 22.8 s, first device +0.1 s, first frame +6.9 s; 2 device(s)
- preset: none
- frames: `pid=11145 comm=Main presents=159545 t_first=1106679.788 t_last=1117023.739 fps_avg=15.4 fps_p50=43.5 ft_p50=23 ft_p90=45 ft_p99=70 ft_max=6050724 hitch100=134 hitch1000=8 fps_seconds=<10:6,10-20:339,20-30:639,30-45:2215,45-60:679,60+:284 swapchains=2 external=7`
- pipelines: 950 built in 1.5 s of compile time, longest 146 ms, 0 failed; by time: <10 ms 926, <50 18, <200 6, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_EXT_depth_clip_enable VK_EXT_robustness2 VK_EXT_vertex_attribute_divisor VK_KHR_load_store_op_none VK_KHR_maintenance5 VK_KHR_maintenance6 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- GPU: device lost 0 time(s); 2 wait(s) over 2 s (longest 8.6 s)
- while it ran: GPU memory peak 2178 MB; system memory available >= 1568 MB; fastest CPU cluster 1800-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 64%; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 2 | 22.9 s | capability check: device 36's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 4 | 29.4 s | dma-buf image refused at tiling 1 (type 0 format 100 4096x1x1 usage 0x7); made without the dma-buf handle type (its memory is exported as allocated) |
| info | 1 | 29.7 s | device 36: first null descriptors replaced by dummies |

## Performance

Per 10-s window while a process presented frames (`perf:` and `perf-threads:` lines in vkbridge-server.log); the verdict names what limited the window most. Present wait per frame: driver (the GPU's work) / queue (our order) / IPC / local.

| process | windows | verdicts | fps (median window) | frame ms p50 / p90 | repeated frames | GPU busy avg / max % | GPU MHz avg / max | present ms: driver / queue / IPC / local |
|---|---:|---|---:|---|---:|---|---|---|
| SkyrimSE.exe (11145) | 410 | CPU 1, COMPILE 4, UPLOAD 10, THERMAL 395 | 34 | 23.1 / 41.5 | 115556 of 159407 | 84 / 99 | 319 / 1300 | 36.46: 22.86 / 0.11 / 0.75 / 12.75 |

Busiest threads over the run (% of a core @ cluster) and the summary lines tools read:

```
perf-summary: pid=11145 comm=SkyrimSE.exe windows=410 verdicts=CPU:1,COMPILE:4,UPLOAD:10,THERMAL:395 fps_med=34 ft_p50_med=23.1 ft_p90_med=41.5 frames=159407 repeats=115556 gpu_busy_avg=84 gpu_busy_max=99 gpu_mhz_avg=319 gpu_mhz_max=1300 present_ms=36.46 driver_ms=22.86 queue_ms=0.11 ipc_ms=0.75 local_ms=12.75 top=Main:21@p0:55/p4:25/p7:18,dxvk-cs:7@p0:34/p4:56,Main:5@p0:34/p4:50/p7:15,SkyrimSE.exe:3@p0:43/p4:47,SkyrimSE.exe:3@p0:41/p4:48,SkyrimSE.exe:3@p0:43/p4:47 others=server:14@p0:52/p4:39,gamescope:2@p0:56/p4:38,Xwayland:0,steam:5@p0:74/p4:22,steamwebhelper:1@p0:70/p4:27,wineserver:2@p0:56/p4:34
cpu-cap: samples=2110 p0=2000/2000MHz(100%) top=1% p4=2850/2850MHz(100%) top=0% p7=3400/3400MHz(100%) top=0% held=none
```

## Server (not tied to a process)

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 0.1 s | memory sharing: hostptr unavailable (driver lacks its extensions) |
| info | 1 | 0.1 s |   dmaheap, type 0: allocation failed (-1000072003) |
| warning | 4 | 0.1 s | probe: dmabuf_linear_image fail: 1D 4096x1 R32F: query -11, create -1000158000; 2D 8x8 RGBA8: query -11, create -1000158000 - handled at run time: such images are made without the handle type (server_emu_layer.c) |
| warning | 2 | 0.1 s | probe: spec_select fail (selected 0 0 0 0 (want 11 22 33 44; zeros: folded at the defaults) - the SPIR-V fix (server_spvfix.c) is on for Arm's driver): SPIR-V spec-constant fix on |
| info | 22 | 1427.7 s | hitches over 100 ms in process 11145 (SkyrimSE.exe) so far: 71 (compile 4, bc 34, alloc 1, pcache 0, wait 17, other 15); worst 2045 ms; 1 of the waits came after BC conversions too small to explain them (bc_gpu_est_ms in their lines) |

## Artefacts

- `/data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/probe-13b5-c8700000-0b001000-1eaa44767a701f8f.json.beat` (138 bytes)
- `/data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/probe-13b5-c8700000-0b001000-1eaa44767a701f8f.json` (10130 bytes)

Pull them with `adb shell run-as com.droiddeck.launcher.mali cat <path>`; `spirv-dis` reads the .spv files.
