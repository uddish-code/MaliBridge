Mode: safe (Setup) - emulations and errata fixes stay on wherever the startup probe has not verified the native path on this GPU and driver; compile watchdog 10 s (safe mode).

# MaliBridge session report

Session started 2026-11-17 23:39:28, report written 2026-11-18 00:12:53 (2005 s in); rewritten every 5 s. Machine-readable: `malibridge-report.json`.

> **Warning, test switch on: overrides from /data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/env in effect: VKBRIDGE_HUD_FPS=12 VKBRIDGE_PACER=1**

## Summary: 29 issues

1. test switch on: overrides from /data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/env in effect: VKBRIDGE_HUD_FPS=12 VKBRIDGE_PACER=1
2. probe dmabuf_linear_image: fail (1D 4096x1 R32F: query -11, create -1000158000; 2D 8x8 RGBA8: query -11, create -1000158000 - handled at run time: such images are made without the handle type (server_emu_layer.c))
3. probe linear_layout: fail (1x1: rowPitch 0 size 64; 1x16: rowPitch 64 size 1024; 16x1: rowPitch 0 size 64 - patched at run time (the server reports the row's size))
4. probe spec_select: fail -> SPIR-V spec-constant fix on (selected 0 0 0 0 (want 11 22 33 44; zeros: folded at the defaults) - the SPIR-V fix (server_spvfix.c) is on for Arm's driver)
5. probe bitwise_vec: fail -> the bug's pattern (MK-03): vector bitwise ops miscompiled (case 0 lanes 0x11 0x2 (want 0x11 0x3) - integer vector bitwise ops miscompiled)
6. probe view3d_layers: crash (the driver faulted (signal 11); the probe device is abandoned)
7. probe pv_mutable_linear: fail (RGBA8: query 0, image export fd (0); BGRA8: query 0, image export fd (0) - the query says yes and the image fails: not the refusal pattern, pv_mutable_linear stays off)
8. warning gamescope: compute layout: immutable YCbCr samplers replaced (this GPU cannot build such pipelines); NV12 surfaces lose YCbCr conversion (x1, first at 1.9 s)
9. warning steamwebhelper: emulation: dual-source blending approximated with the first source (blending may look off) (logged once) (x1, first at 16.3 s)
10. warning steamwebhelper: compile gate: memory is low (1427 MB free of 11525 MB): one pipeline compile at a time until it recovers (logged once) (x1, first at 867.6 s)
11. gamescope: CPU clocks capped to 35% of their maximum while it ran (thermal)
12. gamescope: Android thermal status reached 3
13. Xwayland: CPU clocks capped to 35% of their maximum while it ran (thermal)
14. Xwayland: Android thermal status reached 3
15. Xwayland: CPU clocks capped to 35% of their maximum while it ran (thermal)
16. Xwayland: Android thermal status reached 3
17. steam: CPU clocks capped to 58% of their maximum while it ran (thermal)
18. steam: CPU clocks capped to 35% of their maximum while it ran (thermal)
19. steam: CPU held at a fixed clock while it ran: p0 1600 MHz 71% of the time (the phone's power mode or a per-app limit may be holding it)
20. steam: Android thermal status reached 3
21. steamwebhelper: CPU clocks capped to 35% of their maximum while it ran (thermal)
22. steamwebhelper: Android thermal status reached 3
23. steamwebhelper: CPU clocks capped to 35% of their maximum while it ran (thermal)
24. steamwebhelper: Android thermal status reached 3
25. explorer.exe (steam3960647599): CPU clocks capped to 35% of their maximum while it ran (thermal)
26. explorer.exe (steam3960647599): Android thermal status reached 3
27. SkyrimSE.exe (steam3960647599): CPU clocks capped to 35% of their maximum while it ran (thermal)
28. SkyrimSE.exe (steam3960647599): CPU held at a fixed clock while it ran: p0 1600 MHz 71% of the time (the phone's power mode or a per-app limit may be holding it)
29. SkyrimSE.exe (steam3960647599): Android thermal status reached 3

## Notes (not problems)

1. steam: no frame for the last 1995 s while it runs; another program was in front (normal)
2. explorer.exe (steam3960647599): a device for 1979 s and no frame presented; another program was in front (normal)

## Device

| | |
|---|---|
| model | samsung SM-X820 (aarch64) |
| SoC | MT6989 |
| Android | 16 (SDK 36), build BP4A.251205.006.X820XXU7DZE3 |
| kernel | Linux 6.1.145-android14-11-abX820XXU7DZE3 |
| memory | 11525 MB total, 1482 MB available at the lowest |
| storage | 32248 MB free where the caches live |
| clocks | CPU clusters capped to 35% at the lowest; GPU 26-1300 MHz (from /sys/kernel/gpu/gpu_clock); Android thermal status max 3 (vkbridge-clocks.log) |
| server | pid 12436, its own process, RSS peak 3360 MB |
| GPU 0 | Mali-G720-Immortalis MC12, Vulkan 1.3.247 to the server; memory sharing dmaheap; missing 0x461deef, emulating 0x463ffff |

## Bridge

Build `v0.5.5-441-g5b8c16c`, protocol `e88f0e43c2b566b9`. Cache directory `/data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines`.

Overrides from `<cache dir>/env`: `VKBRIDGE_HUD_FPS=12 VKBRIDGE_PACER=1`

Server environment: (no VKBRIDGE_/VK_ variables)

## Startup probe

Profile `/data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/probe-13b5-c8700000-0b001000-1eaa44767a701f8f.json` - Mali-G720-Immortalis MC12, Mali-G720-Immortalis MC12 v1.r44p1-01eac0.97cfdb5d49b593ea0a6dc1bdbc33dec8; from the cache, 1 ms at start (background part pending).

Emulation mask: 0x463ffff before the probe; after it 0x463ffff in safe mode, 0x463ffff in performance mode (safe mode in force: a probe that has not verified the native path keeps its emulation).

| probe | result | ms | decision (safe mode) | detail |
|---|---|---:|---|---|
| identity | pass | 1.3 |  | Mali-G720-Immortalis MC12, Vulkan 1.3.247, driver 0x0b001000 (Mali-G720-Immortalis MC12: v1.r44p1-01eac0.97cfdb5d49b593ea0a6dc1bdbc33dec8), 119 device extensions |
| memory_types | pass | 0.5 |  | 0:0x7=ok,mapped 1:0xb=ok,mapped 2:0x11=ok 3:0x21=protected; images: types 0x3, ordinary device-local 0 |
| dma_heaps | pass | 0.2 |  | mtk_prot_region-aligned=ok mtk_prot_region=ok mtk_sapu_data_shm_region-aligned=ok mtk_sapu_data_shm_region=ok mtk_sapu_engine_shm_region-aligned=ok mtk_sapu_engine_shm_region=ok mtk_svp_region-aligned=ok mtk_svp_region=ok mtk_wfd_region-aligned=ok mtk_wfd_region=ok mtk_tui_region-aligned=Permission denied mtk_tui_region=Permission denied mtk_prot_page-uncached=ok mtk_sapu_page-uncached=Permission denied mtk_svp_page-uncached=ok mtk_wfd_page-uncached=ok mtk_camera-uncached=Permission denied mtk_mm=ok system=ok mtk_camera=Permission denied mtk_mm-uncached=ok system-uncached=ok mtk_slc=Permission denied; the bridge's dma-heap: availab |
| dmabuf_export | skip | 0.0 |  | query (optimal RGBA8): -11, features 0x0; not claimed exportable (emulated, pages from the dma-heap) |
| dmabuf_linear_image | **fail** | 0.0 |  | 1D 4096x1 R32F: query -11, create -1000158000; 2D 8x8 RGBA8: query -11, create -1000158000 - handled at run time: such images are made without the handle type (server_emu_layer.c) |
| ahb_share | skip | 0.0 |  | not needed: the driver takes dma-bufs |
| linear_layout | **fail** | 0.4 |  | 1x1: rowPitch 0 size 64; 1x16: rowPitch 64 size 1024; 16x1: rowPitch 0 size 64 - patched at run time (the server reports the row's size) |
| compressed_formats | pass | 0.0 |  | BC1:--- BC3:--- BC4:--- BC5:--- BC6H:--- BC7:--- ETC2:sft EAC-RG11s:sft ASTC4x4:sft ASTC4x4-HDR:sft (s sampled, f linear filter, t transfer dst) |
| bc_native | skip | 0.0 |  | BC emulated |
| compression | pass | 0.3 |  | plain: compression 0x0; storage: compression 0x4 (0x0 default/compressed, 0x4 disabled) |
| descriptor_pool | pass | 0.1 |  | pool for 16 sets gave 16, then -1000069000 |
| bindless_limits | pass | 0.0 |  | UAB per stage: sampled 500000 storage img 500000 storage buf 500000; 500000: support 1, create 0; 1000000: support 0, create 0 |
| null_descriptor | skip | 0.0 |  | robustness2 emulated (null stand-ins) |
| push_descriptor | skip | 0.0 |  | push descriptors emulated |
| multi_draw_indirect | pass | 14.6 |  | 2 draws in one indirect call: 0 0 255 0 0 255 0 0 (want columns 2 and 5) |
| divisor | skip | 0.0 |  | divisor emulated |
| depth_clip | skip | 0.0 |  | depth clip emulated |
| clip_distance | skip | 0.0 |  | clip distance emulated |
| spec_select | **fail** | 5.7 | SPIR-V spec-constant fix on | selected 0 0 0 0 (want 11 22 33 44; zeros: folded at the defaults) - the SPIR-V fix (server_spvfix.c) is on for Arm's driver |
| waits | pass | 3.3 |  | unsignalled fence: wait 0 -> 2, 1 ms -> 2; timeline at 0, wait for 1: 0 -> 2, 2 ms -> 2 after 2.1 ms; signalled by a submission (0): wait -> 0, value 1 |
| layer_vs | pass | 5.1 |  | 8 points into layer 1: layer 0 has 0, layer 1 has 8 (compiled in 3.4 ms) |
| layer_gs | pass | 23.5 |  | 8 points into layer 1: layer 0 has 0, layer 1 has 8 (compiled in 19.8 ms) |
| pipeline_cache | pass | 3.7 |  | cold 3.4 ms, from 1713 bytes of cache data 0.0 ms (cache from data: 0) |
| viewport_flip | pass | 6.7 |  | viewport (0,4,4,-4) rows lit 0011 (want 0011), (4,0,4,4) 1100 (want 1100); facing front / back (want different); no multiViewport with the VS's ViewportIndex: two viewports not tried |
| bitwise_vec | **fail** | 8.2 | the bug's pattern (MK-03): vector bitwise ops miscompiled | case 0 lanes 0x11 0x2 (want 0x11 0x3) - integer vector bitwise ops miscompiled |
| dyn_state | pass | 10.8 |  | after a bind: depth write off kept (rgb 0 0 255), cull FRONT_AND_BACK kept, stencil write mask 0 kept (stencil 0); no EDS3 sample mask |
| vb_strides | pass | 4.9 |  | one call from binding 0: right; one call from binding 1: right; single-binding calls: right |
| view3d_layers | **crash** | 0.3 |  | the driver faulted (signal 11); the probe device is abandoned |
| pv_mutable_linear | **fail** | 0.1 |  | RGBA8: query 0, image export fd (0); BGRA8: query 0, image export fd (0) - the query says yes and the image fails: not the refusal pattern, pv_mutable_linear stays off |
| pv_bgra_store | skip | 0.0 |  | not a PowerVR driver: not run |
| pv_names | skip | 0.0 |  | not a PowerVR driver: not run |
| fp16_math | pass | 16.3 |  | fma, range, conversions, relaxed precision and a 16-bit accumulation right |
| wait_eintr | pass | 1000.4 |  | fence, 500 ms wait, 3 signal(s) into it: 2 after 500 ms; timeline semaphore, 500 ms wait, 3 signal(s) into it: 2 after 500 ms |
| rendering_churn | pass | 248.5 |  | 256 views made, rendered to, read back and destroyed: 0 wrong |
| compile_lut_standin | pass | 16.0 |  | the compile watchdog's LUT stand-in: built in 16 ms |
| compile_aces | pass | 167.6 |  | UE4-LUT-shaped fragment shader (56348 bytes of SPIR-V): built in 167 ms |
| bc_transcoders | pass | 1204.9 |  | BC1->ETC2 0 ms, BC2->ASTC 0 ms, BC3->ASTC 0 ms, BC4->EAC 0 ms, BC5->EAC 0 ms, BC6H->ASTC-HDR 0 ms, BC7->ASTC 1187 ms |
| bc_variants | pass | 18777.9 |  | 26 same as the old variants |

Driver errata, GPU 0 (decided at each vkCreateDevice; mode now: safe):

| erratum | item | probe | probe result | safe mode | performance mode |
|---|---|---|---|---|---|
| wait_retry | MK-01 | wait_eintr (records) | pass | **ON** (always; safe mode; probe wait_eintr passed, recorded only) - in force | **ON** (always; performance mode; probe wait_eintr passed, recorded only) | 
| viewport_flip | MK-02 | viewport_flip | pass | off (not needed here) - in force | off (not needed here) | 
| bitwise_scalar | MK-03 | bitwise_vec | **fail (or)** | **ON** (probe bitwise_vec failed; r44p1 in r18p0-r53; safe mode) - in force | **ON** (probe bitwise_vec failed; performance mode) | 
| dyn_reemit | MK-04 | dyn_state | pass | off (not needed here) - in force | off (not needed here) | 
| vb_split | MK-05 | vb_strides (records) | pass | **ON** (always; safe mode; probe vb_strides passed, recorded only) - in force | **ON** (always; performance mode; probe vb_strides passed, recorded only) | 
| view_quarantine | MK-06 | rendering_churn (records) | pass | **ON** (always; safe mode; probe rendering_churn passed, recorded only) - in force | off (not needed here) | 
| view_counts | MK-07 | view3d_layers (records) | **crash** | **ON** (always; safe mode) - in force | **ON** (always; performance mode) | 
| clamp_zero | MK-32 | none (by version) | - | **ON** (r44p1 in r38p1-r49p0; safe mode) - in force | **ON** (r44p1 in r38p1-r49p0; performance mode) | 
| cull_nontri | MK-16 | none (by version) | - | **ON** (always; safe mode) - in force | **ON** (r44p1 in r0p0-r51 (ANGLE: below r52; Arm: r41p0-r49p2, r50p0-r51p0); performance mode) | 
| dedicated_import | MK-39 | none (by version) | - | **ON** (r44p1 in r0p0-r54p0 (fixed between r32p1 and r54p1); safe mode) - in force | **ON** (r44p1 in r0p0-r54p0 (fixed between r32p1 and r54p1); performance mode) | 
| fp16_hide | MK-20 | fp16_math | pass | off (not needed here) - in force | off (not needed here) | 
| stencil_layout | MK-11 | none (by version) | - | **ON** (r44p1 in r41p0-r54p0 (Arm 4021056, fixed in r54p1); safe mode) - in force | **ON** (r44p1 in r41p0-r54p0 (Arm 4021056, fixed in r54p1); performance mode) | 
| vb_bake | MK-05 | vb_strides | pass | off (not needed here) - in force | off (not needed here) | 
| gs_hide | #11 | none (by version) | - | off (not needed here) - in force | off (not needed here) | 
| split_varying | MK-47 | none (by version) | - | **ON** (r44p1 in r0p0-on (every Arm driver (a player log r38p1, a player log r49p1)); safe mode) - in force | **ON** (r44p1 in r0p0-on (every Arm driver (a player log r38p1, a player log r49p1)); performance mode) | 
| import_serial | MK-48 | none (by version) | - | off (not needed here) - in force | off (not needed here) | 
| pv_mutable_linear | PV-02 | pv_mutable_linear | **fail (rgba8, bgra8)** | off (not needed here) - in force | off (not needed here) | 
| pv_bgra_store | PV-07 | pv_bgra_store | skip | off (not needed here) - in force | off (not needed here) | 
| pv_names | PV-01 | pv_names | skip | off (not needed here) - in force | off (not needed here) | 
| pv_view3d_base | PV-04 | view3d_layers | **crash** | off (not needed here) - in force | off (not needed here) | 
| pv_fbloop_split | PV-06 | view3d_layers | **crash** | off (not needed here) - in force | off (not needed here) | 
| pv_zink_name | PV-08 | zink_profile | not run (not a PowerVR driver, or it could not run) | off (not needed here) - in force | off (not needed here) | 
| fragdepth_nodepth | MK-49 | none (by version) | - | off (not needed here) - in force | off (not needed here) | 

## Processes

### droiddeck-vkbri - pid 13102

- application `vkbridge-smoke`, engine vkbridge 0.0.1, Vulkan 1.2 requested
- connected at 1.2 s, first device +0.0 s, exited at 1.3 s (ran 0.1 s); 1 device(s)
- preset: none
- frames: none reported by the client
- pipelines: 5 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 5, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_push_descriptor VK_EXT_robustness2

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 1.2 s | capability check: device 2's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 1.2 s | errata: bitwise_scalar ON (probe bitwise_vec failed; r44p1 in r18p0-r53; safe mode) - MK-03 |
| info | 1 | 1.2 s | device 2: null descriptors in push descriptor writes replaced by dummies |
| info | 1 | 1.2 s | device 2: first null descriptors replaced by dummies |
| info | 1 | 1.3 s | device 2: 2 null descriptors replaced, 0 images by stand-ins of their binding's shape; 0 bindings where pipelines disagree on the shape |
| info | 1 | 1.3 s | errata: dedicated_import: 13 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### gamescope - pid 13278 (running)

- application `gamescope`, engine hopefully not just some code 1.0.0, Vulkan 1.3 requested
- connected at 1.8 s, first device +0.0 s; 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 48 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 147 built in 0.0 s of compile time, longest 1 ms, 0 failed; by time: <10 ms 147, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_EXT_robustness2
- while it ran: GPU memory peak 49 MB; system memory available >= 1482 MB; fastest CPU cluster 700-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 71%; GPU 26-1300 MHz; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 1.8 s | capability check: device 4's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| warning | 1 | 1.9 s | compute layout: immutable YCbCr samplers replaced (this GPU cannot build such pipelines); NV12 surfaces lose YCbCr conversion |
| info | 4 | 867.1 s | dma-buf image refused at tiling 1 (type 1 format 1000156003 1280x720x1 usage 0xa); made without the dma-buf handle type (its memory is exported as allocated) |
| info | 1 | 867.1 s | device 4: first null descriptors replaced by dummies |

### Xwayland - pid 13312 (running)

- application `Xwayland`, engine mesa zink 0.0.0, Vulkan 1.4 requested
- connected at 2.6 s, first device +0.0 s; 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 23 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 2 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 2, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 29 MB; system memory available >= 1482 MB; fastest CPU cluster 700-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 71%; GPU 26-1300 MHz; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 2.6 s | capability check: device 8's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 22.0 s | device 8: first null descriptors replaced by dummies |

### Xwayland - pid 13311 (running)

- application `Xwayland`, engine mesa zink 0.0.0, Vulkan 1.4 requested
- connected at 2.6 s, first device +0.0 s; 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 151 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 3 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 3, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 66 MB; system memory available >= 1482 MB; fastest CPU cluster 700-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 71%; GPU 26-1300 MHz; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 2.6 s | capability check: device 7's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 7.7 s | device 7: first null descriptors replaced by dummies |

### steam - pid 13865

- application `steam`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 5.7 s, first device +0.0 s, first frame +0.2 s, exited at 8.1 s (ran 2.4 s); 1 device(s)
- preset: none
- frames: `pid=13865 comm=steam presents=122 t_first=1096509.256 t_last=1096510.257 fps_avg=120.9 fps_p50=125.0 ft_p50=8 ft_p90=13 ft_p99=15 ft_max=18 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:1 swapchains=1 external=3`
- pipelines: 4 built in 0.0 s of compile time, longest 4 ms, 0 failed; by time: <10 ms 4, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 39 MB; system memory available >= 4659 MB; fastest CPU cluster 1600-1600 MHz, capped to 58%; GPU 260-260 MHz; thermal status max 0

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 5.7 s | capability check: device 10's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 5.8 s | device 10: first null descriptors replaced by dummies |
| info | 1 | 7.9 s | vertex input: 4 pipeline(s) kept (at most 33 KB of create infos and shaders at once), 4 variant(s) made (at most 1 for one pipeline), 0 failed, 649 variant bind(s), 0 draw(s) dropped; vkCmdSetVertexInputEXT: 0 passed to the driver, 649 held, 0 sent again; 0 pipeline(s) not kept; 0 extended dynamic state call(s) |
| info | 1 | 7.9 s | device 10: 2596 null descriptors replaced, 0 images by stand-ins of their binding's shape; 0 bindings where pipelines disagree on the shape |
| info | 1 | 7.9 s | errata: dedicated_import: 8 import(s), 0 with the dedicated struct taken off, 3 kept (resource made for the handle type); imitated: 0 failed |

### steam - pid 13862 (running)

- application `steam`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 8.5 s, first device +0.0 s, first frame +1.6 s; 3 device(s)
- preset: none
- frames: `pid=13862 comm=steam presents=1 t_first=1096513.508 t_last=1096513.508 fps_avg=0.0 fps_p50=0.0 ft_p50=0 ft_p90=0 ft_p99=0 ft_max=0 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:0 swapchains=5 external=12`
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 12 MB; system memory available >= 1482 MB; fastest CPU cluster 700-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 71%; GPU 26-1300 MHz; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 3 | 8.5 s | capability check: device 12's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 2 | 8.6 s | errata: dedicated_import: 5 import(s), 0 with the dedicated struct taken off, 3 kept (resource made for the handle type); imitated: 0 failed |

### steamsysinfo - pid 13941

- application `Steam Gpu Query`, engine Steam Gpu Query Engine 1.0.0, Vulkan 1.2 requested
- connected at 8.6 s, exited at 8.7 s (ran 0.1 s); 0 device(s)
- preset: none

### steamwebhelper - pid 13973 (running)

- application `steamwebhelper`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 9.5 s, first device +0.0 s; 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 22 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 2 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 2, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 30 MB; system memory available >= 1482 MB; fastest CPU cluster 700-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 71%; GPU 26-1300 MHz; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 9.5 s | capability check: device 19's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 12.2 s | device 19: first null descriptors replaced by dummies |

### steamwebhelper - pid 14128 (running)

- application `steamwebhelper`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 9.8 s, first device +0.2 s; 1 device(s)
- preset: none
- frames: not through the bridge (no swapchain; 51 allocation(s) exported or imported as fds: it presents through a compositor or another path)
- pipelines: 78 built in 0.0 s of compile time, longest 1 ms, 0 failed; by time: <10 ms 78, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 329 MB; system memory available >= 1482 MB; fastest CPU cluster 700-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 71%; GPU 26-1300 MHz; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 10.0 s | capability check: device 24's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 10.2 s | opaque fd emulation: the driver refused a dma-buf resource; made without (its export will fail) |
| info | 1 | 11.3 s | device 24: first null descriptors replaced by dummies |
| warning | 1 | 16.3 s | emulation: dual-source blending approximated with the first source (blending may look off) (logged once) |
| warning | 1 | 867.6 s | compile gate: memory is low (1427 MB free of 11525 MB): one pipeline compile at a time until it recovers (logged once) |

### gldriverquery - pid 14141

- application `gldriverquery`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 9.9 s, first device +0.0 s, first frame +0.1 s, exited at 10.1 s (ran 0.2 s); 1 device(s)
- preset: none
- frames: `pid=14141 comm=gldriverquery presents=1 t_first=1096513.439 t_last=1096513.439 fps_avg=0.0 fps_p50=0.0 ft_p50=0 ft_p90=0 ft_p99=0 ft_max=0 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:0 swapchains=2 external=0`
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 9.9 s | capability check: device 22's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 10.1 s | errata: dedicated_import: 4 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### gldriverquery - pid 14228

- application `gldriverquery`, engine mesa zink 0.0.0, Vulkan 1.3 requested
- connected at 10.3 s, first device +0.0 s, first frame +0.1 s, exited at 10.5 s (ran 0.2 s); 1 device(s)
- preset: none
- frames: `pid=14228 comm=gldriverquery presents=1 t_first=1096513.814 t_last=1096513.814 fps_avg=0.0 fps_p50=0.0 ft_p50=0 ft_p90=0 ft_p99=0 ft_max=0 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:0 swapchains=2 external=0`
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 10.3 s | capability check: device 26's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 10.4 s | errata: dedicated_import: 4 import(s), 0 with the dedicated struct taken off, 0 kept (resource made for the handle type); imitated: 0 failed |

### vulkandriverque - pid 14298

- application `hellovr_vulkan`, engine -, Vulkan 1.0 requested
- connected at 10.5 s, first device +0.0 s, exited at 10.5 s (ran 0.0 s); 1 device(s)
- preset: none
- frames: none reported by the client
- pipelines: 1 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 1, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 10.5 s | capability check: device 28's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |

### vulkandriverque - pid 14308

- application `hellovr_vulkan`, engine -, Vulkan 1.0 requested
- connected at 10.6 s, first device +0.0 s, exited at 10.6 s (ran 0.1 s); 1 device(s)
- preset: none
- frames: none reported by the client
- pipelines: 1 built in 0.0 s of compile time, longest 0 ms, 0 failed; by time: <10 ms 1, <50 0, <200 0, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 10.6 s | capability check: device 30's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |

### explorer.exe (steam3960647599) - pid 14945

- application `explorer.exe`, engine mesa zink 0.0.0, Vulkan 1.4 requested
- connected at 21.8 s, first device +0.1 s, exited at 2000.5 s (ran 1978.7 s); 1 device(s)
- preset: none
- frames: `pid=14945 comm=explorer.exe presents=0 t_first=0.000 t_last=0.000 fps_avg=0.0 fps_p50=0.0 ft_p50=0 ft_p90=0 ft_p99=0 ft_max=0 hitch100=0 hitch1000=0 fps_seconds=<10:0,10-20:0,20-30:0,30-45:0,45-60:0,60+:0 swapchains=1 external=1`
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_KHR_maintenance5 VK_KHR_maintenance6 VK_EXT_robustness2 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state VK_EXT_depth_clip_enable
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 4 MB; system memory available >= 1482 MB; fastest CPU cluster 700-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 71%; GPU 26-1300 MHz; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 21.9 s | capability check: device 33's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 1 | 2000.5 s | errata: dedicated_import: 5 import(s), 0 with the dedicated struct taken off, 3 kept (resource made for the handle type); imitated: 0 failed |

### SkyrimSE.exe (steam3960647599) - pid 15005

- application `SkyrimSE.exe`, engine mesa zink 0.0.0, Vulkan 1.4 requested
- connected at 27.3 s, first device +0.1 s, first frame +7.0 s, exited at 2001.1 s (ran 1973.8 s); 2 device(s)
- preset: none
- frames: `pid=15005 comm=Main presents=94028 t_first=1096537.667 t_last=1098501.503 fps_avg=47.9 fps_p50=55.6 ft_p50=18 ft_p90=29 ft_p99=47 ft_max=1834 hitch100=103 hitch1000=2 fps_seconds=<10:2,10-20:18,20-30:140,30-45:532,45-60:962,60+:279 swapchains=2 external=7`
- pipelines: 795 built in 1.2 s of compile time, longest 128 ms, 0 failed; by time: <10 ms 779, <50 11, <200 5, <1 s 0, <2 s 0, <5 s 0, <10 s 0, more 0
- device extensions it asked for that the driver lacks (emulated, aliased or client-side): VK_EXT_depth_clip_enable VK_EXT_robustness2 VK_EXT_vertex_attribute_divisor VK_KHR_load_store_op_none VK_KHR_maintenance5 VK_KHR_maintenance6 VK_KHR_vertex_attribute_divisor VK_KHR_push_descriptor VK_EXT_vertex_input_dynamic_state
- features it enabled that the GPU lacks (emulated): dualSrcBlend fillModeNonSolid multiViewport textureCompressionBC shaderClipDistance shaderCullDistance
- while it ran: GPU memory peak 2434 MB; system memory available >= 1482 MB; fastest CPU cluster 700-3400 MHz, capped to 35%; CPU held: p0 1600 MHz 71%; GPU 26-1300 MHz; thermal status max 3

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 2 | 27.3 s | capability check: device 36's driver lacks ClipDistance (shaderClipDistance), CullDistance (shaderCullDistance), Float64 (shaderFloat64), StorageImageMultisample (shaderStorageImageMultisample); a pipeline that still asks for clip/cull distances at the driver is refused |
| info | 4 | 33.8 s | dma-buf image refused at tiling 1 (type 0 format 100 4096x1x1 usage 0x7); made without the dma-buf handle type (its memory is exported as allocated) |
| info | 1 | 34.2 s | device 36: first null descriptors replaced by dummies |
| info | 1 | 2000.6 s | device 36: 1225843 null descriptors replaced, 651420 images by stand-ins of their binding's shape; 12 bindings where pipelines disagree on the shape |
| info | 2 | 2000.7 s | errata: dedicated_import: 17 import(s), 0 with the dedicated struct taken off, 4 kept (resource made for the handle type); imitated: 0 failed |

## Performance

Per 10-s window while a process presented frames (`perf:` and `perf-threads:` lines in vkbridge-server.log); the verdict names what limited the window most. Present wait per frame: driver (the GPU's work) / queue (our order) / IPC / local.

| process | windows | verdicts | fps (median window) | frame ms p50 / p90 | repeated frames | GPU busy avg / max % | GPU MHz avg / max | present ms: driver / queue / IPC / local |
|---|---:|---|---:|---|---:|---|---|---|
| SkyrimSE.exe (15005) | 192 | GPU 1, UPLOAD 4, THERMAL 180, NONE 7 | 48 | 18.6 / 28.9 | 3561 of 94029 | 78 / 99 | 486 / 1300 | 21.17: 16.31 / 0.24 / 1.55 / 3.07 |

Busiest threads over the run (% of a core @ cluster) and the summary lines tools read:

```
perf-summary: pid=15005 comm=SkyrimSE.exe windows=192 verdicts=GPU:1,UPLOAD:4,THERMAL:180,NONE:7 fps_med=48 ft_p50_med=18.6 ft_p90_med=28.9 frames=94029 repeats=3561 gpu_busy_avg=78 gpu_busy_max=99 gpu_mhz_avg=486 gpu_mhz_max=1300 present_ms=21.17 driver_ms=16.31 queue_ms=0.24 ipc_ms=1.55 local_ms=3.07 top=Main:49@p0:24/p4:40/p7:34,Main:29@p0:23/p4:64/p7:11,dxvk-cs:21@p0:38/p4:44/p7:17,SkyrimSE.exe:15@p0:41/p4:44/p7:13,SkyrimSE.exe:15@p0:41/p4:44/p7:13,SkyrimSE.exe:15@p0:38/p4:48/p7:13 others=server:40@p0:44/p4:41/p7:13,gamescope:7@p0:52/p4:35/p7:12,Xwayland:1@p0:52/p4:31/p7:15,steam:16@p0:55/p4:34,steamwebhelper:3@p0:52/p4:44,wineserver:8@p0:59/p4:32
cpu-cap: samples=980 p0=2000/2000MHz(100%) top=9% p4=2850/2850MHz(100%) top=6% p7=3400/3400MHz(100%) top=1% held=none
```

## Server (not tied to a process)

| level | count | first at | first occurrence |
|---|---:|---:|---|
| info | 1 | 0.1 s | memory sharing: hostptr unavailable (driver lacks its extensions) |
| info | 1 | 0.1 s |   dmaheap, type 0: allocation failed (-1000072003) |
| warning | 4 | 0.2 s | probe: dmabuf_linear_image fail: 1D 4096x1 R32F: query -11, create -1000158000; 2D 8x8 RGBA8: query -11, create -1000158000 - handled at run time: such images are made without the handle type (server_emu_layer.c) |
| warning | 2 | 0.2 s | probe: spec_select fail (selected 0 0 0 0 (want 11 22 33 44; zeros: folded at the defaults) - the SPIR-V fix (server_spvfix.c) is on for Arm's driver): SPIR-V spec-constant fix on |
| info | 12 | 1246.2 s | hitches over 100 ms in process 15005 (SkyrimSE.exe) so far: 65 (compile 3, bc 12, alloc 1, pcache 0, wait 24, other 25); worst 1835 ms; 1 of the waits came after BC conversions too small to explain them (bc_gpu_est_ms in their lines) |

## Artefacts

- `/data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/probe-13b5-c8700000-0b001000-1eaa44767a701f8f.json.beat` (138 bytes)
- `/data/user/0/com.droiddeck.launcher.mali/files/vkbridge-pipelines/probe-13b5-c8700000-0b001000-1eaa44767a701f8f.json` (10130 bytes)

Pull them with `adb shell run-as com.droiddeck.launcher.mali cat <path>`; `spirv-dis` reads the .spv files.
